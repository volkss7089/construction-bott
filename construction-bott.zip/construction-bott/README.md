# Construction Report Bot

Telegram-бот для управления отчетностью в строительных бригадах.

## Установка

1. Клонировать репозиторий:
```bash
git clone https://github.com/yourname/construction-bot.git